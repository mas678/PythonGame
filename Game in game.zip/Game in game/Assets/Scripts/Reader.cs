﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

public class Reader : MonoBehaviour
{
    [FormerlySerializedAs("panel")] [SerializeField] private GameObject endPanel;
    [SerializeField] private ParticleSystem particle;
    [SerializeField] TMP_InputField field;
    [SerializeField] Text sad;
    [SerializeField] Text errorText;
    [SerializeField] private GameObject errorField;
    [SerializeField] private Animator errorAnim;
    [SerializeField] private List<string> output;
    [SerializeField] private List<string> input;
    [SerializeField] private Animator endAnim;
    [SerializeField] private GameObject buttonHelp;
    [SerializeField] private Animator tryAgainAnim;
    [SerializeField] private GameObject tryAgain;
    public bool isActive = false;
    private bool isEnd = false;

    private bool Testing(int ind)
    {
        string s = field.text;
        try
        {
            string ans = PythonStarter.Start(s, input[ind]);
            Debug.Log(ans);
            return ans.Equals(output[ind]);
        }
        catch (Exception e)
        {
            Debug.Log("Error");
            errorText.text = e.Message;
            errorAnim.SetBool("is_open", true);
            //errorField.SetActive(true);
        }

        return false;
    }

    public void ButtonHelp()
    {
        if (isEnd)
        {
            return;
        }
        buttonHelp.SetActive(!buttonHelp.activeSelf);
    }

    private void OnClick()
    {
        tryAgain.SetActive(false);
        tryAgainAnim.SetBool("isWrong", false);
        if (isEnd)
        {
            return;
        }

        bool x = true;
        for (int i = 0; i < input.Count; i++)
        {
            x = Testing(i);
            if (!x)
            {
                break;
            }
        }
        if (x)
        {
            StartCoroutine(Checker(output[0]));
        }
        else
        {
            tryAgain.SetActive(true);
            tryAgainAnim.SetBool("isWrong", true);
        }
        
    }

    // private IEnumerator Wait(float a)
    // {
    //     yield return new WaitForSeconds(a);
    // }

    private IEnumerator Checker(string something)
    {
        isEnd = true;
        errorAnim.SetBool("is_open", false);
        yield return new WaitForSeconds(0.25f);
        sad.text = something;
        particle.Play();
        yield return new WaitForSeconds(1f);
        endPanel.SetActive(true);
        endAnim.SetBool("End", true);
    }
    
    // Start is called before the first frame update
    void Start()
    {
        tryAgain.SetActive(false);
        buttonHelp.SetActive(isActive);
        endPanel.SetActive(false);
        //errorField.SetActive(false);
    }

    public void ButtonTryAgain()
    {
        tryAgain.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
    }
}
