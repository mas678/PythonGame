﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class NextLevel : MonoBehaviour
{

    private Animator anim;
    [SerializeField] private string levelName;
    public Slider slider;
    public GameObject loadingScreen;
    public void Shade()
    {
        anim.SetTrigger("Shade");
    }

    public void ChangeLevel()
    {
        SceneManager.LoadScene(levelName);
        StartCoroutine(LoadingScreen());
    }

    private IEnumerator LoadingScreen()
    {
        AsyncOperation operation = SceneManager.LoadSceneAsync(levelName);
        loadingScreen.SetActive(true);
        while (!operation.isDone)
        {
            float progress = Mathf.Clamp01(operation.progress / .9f);
            slider.value = progress;
            yield return null;
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        Debug.Log(anim == null);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
