﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StartDialog : MonoBehaviour
{
    [SerializeField] private Text dialog;
    [SerializeField] private GameObject dialogWindow;
    [SerializeField] private List<string> phrases;

    private int ind = 1;

    private bool isTalking = false;

    private IEnumerator coroutine;
    // Start is called before the first frame update
    void Start()
    {
        dialog.text = phrases[0];
    }

    public void NextPhrase()
    {
        Debug.Log("OK");
        if (isTalking)
        {
            isTalking = false;
            StopCoroutine(coroutine);
            dialog.text = phrases[ind - 1];
            return;
        }
        if (ind == phrases.Count)
        {
            dialogWindow.SetActive(false);
            return;
        }
        Debug.Log(ind);
        coroutine = PrintingText(phrases[ind++]);
        StartCoroutine(coroutine);
    }

    private IEnumerator PrintingText(string text)
    {
        isTalking = true;
        dialog.text = "";
        for (int i = 0; i < text.Length; i++)
        {
            dialog.text += text[i];
            yield return new WaitForSeconds(0.1f);
        }
        isTalking = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("space"))
        {
            NextPhrase();
        }
    }
}
