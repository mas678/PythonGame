﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Checker2 : MonoBehaviour
{
    [SerializeField] private GameObject endPanel;
    [SerializeField] private Animator endAnim;
    [SerializeField] private List<string> answers;
    [SerializeField] private List<InputField> fields;
    [SerializeField] private List<GameObject> right;
    [SerializeField] private List<ParticleSystem> rightParticles;
    [SerializeField] private List<GameObject> wrong;
    [SerializeField] private List<Animator> wrongAnim;
    
    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < answers.Count; i++)
        {
            right[i].SetActive(false);
            wrong[i].SetActive(false);
        }
        endPanel.SetActive(false);
    }

    public void Check()
    {
        StartCoroutine(Checker());
    }

    private IEnumerator Checker()
    {
        int x = 0;
        for (int i = 0; i < answers.Count; i++)
        {
            right[i].SetActive(false);
            wrong[i].SetActive(false);
            wrongAnim[i].SetBool("is_open",false);
            if (fields[i].text.Equals(answers[i]))
            {
                x++;
                right[i].SetActive(true);
                rightParticles[i].Play();
            }
            else
            {
                wrong[i].SetActive(true);
                wrongAnim[i].SetBool("is_open", true);
            }

            yield return new WaitForSeconds(0.35f);
        }

        if (x == answers.Count)
        {
            endPanel.SetActive(true);
            endAnim.SetBool("End", true);
        }
    }
    
    

    // Update is called once per frame
    void Update()
    {
        
    }
}
