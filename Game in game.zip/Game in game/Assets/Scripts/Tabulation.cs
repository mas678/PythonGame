﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Tabulation : MonoBehaviour
{
    [SerializeField]
    TMP_InputField field;
    public void Enter()
    {
        string s = field.text;
        if (s.Length > 1 && s[s.Length - 2] == ':')
        {
            field.text += "\t";
            field.MoveToEndOfLine(false, false);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyUp(KeyCode.Return)) { Enter(); }
    }
}
