﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using Debug = UnityEngine.Debug;

public static class PythonStarter
{
    // Start is called before the first frame update
    public static string Start(string text, string input)
    {
        string path = @"file.py";
        // string path2 = @"C:\Users\3-q3\Desktop\linal_again.py";
        // string mainPath = "C:\\Windows\\System32;C:\\ProgramFiles\\Python\\\\bin;C:\\OpenSSL\\bin";
        // string txtPath = "text.txt";
        //File.WriteAllText(txtPath,"");
        
        File.WriteAllText(path, text);
        //File.AppendAllText(path, "\nprint(1)");

        // Open the file to read from.
        Debug.Log(Path.GetFullPath(path));
        ProcessStartInfo startInfo = new ProcessStartInfo("cmd.exe");
        startInfo.CreateNoWindow = true;
        startInfo.UseShellExecute = false;
        startInfo.RedirectStandardOutput = true;
        startInfo.RedirectStandardError = true;
        startInfo.StandardErrorEncoding = Encoding.UTF8;
        startInfo.StandardOutputEncoding = Encoding.UTF8;

        startInfo.Arguments = "/c " + path + "\n" + input;
        Process newProcess = Process.Start(startInfo);

        StreamReader reader = newProcess.StandardOutput;
        string output = reader.ReadToEnd().Trim();
        string error = newProcess.StandardError.ReadToEnd();
        newProcess.WaitForExit();
        if (error.Length > 0)
        {
            throw new Exception(error);
        }
        else
        {
            return output;
        }
    }
}