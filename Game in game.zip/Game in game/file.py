n = int(input())
a = int(input())
print(n // a)